-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: database_platinum_komputer_sql
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `barang`
--

DROP TABLE IF EXISTS `barang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `barang` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode_barang` varchar(50) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `kategori_id` int NOT NULL,
  `satuan_id` int NOT NULL,
  `harga_beli` decimal(12,2) NOT NULL DEFAULT '0.00',
  `harga_jual` decimal(12,2) NOT NULL DEFAULT '0.00',
  `stok` int NOT NULL DEFAULT '0',
  `foto_produk` varchar(255) DEFAULT NULL,
  `supplier_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kode_barang` (`kode_barang`),
  KEY `fk_barang_kategori` (`kategori_id`),
  KEY `fk_barang_satuan` (`satuan_id`),
  KEY `idx_supplier_barang` (`supplier_id`),
  CONSTRAINT `fk_barang_kategori` FOREIGN KEY (`kategori_id`) REFERENCES `kategori` (`id`),
  CONSTRAINT `fk_barang_satuan` FOREIGN KEY (`satuan_id`) REFERENCES `satuan` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `barang`
--

LOCK TABLES `barang` WRITE;
/*!40000 ALTER TABLE `barang` DISABLE KEYS */;
INSERT INTO `barang` VALUES (1,'LPT001','Laptop ASUS X441BA',1,1,350000000.00,420000000.00,10,'produk_687461c4a109e_1752457668.png',NULL),(2,'LPT002','Laptop Acer Aspire 3',1,1,4000000.00,4800000.00,7,'produk_687458dbe9165_1752455387.jpg',NULL),(3,'PC001','PC Built Up Core i5',2,1,4500000.00,5400000.00,5,'produk_687458b164cc4_1752455345.png',NULL),(4,'ACC001','Mouse Wireless Logitech',3,1,75000.00,120000.00,24,'produk_6874588eeca4d_1752455310.jpg',NULL),(5,'ACC002','Keyboard Gaming RGB',3,1,250000.00,350000.00,20,'produk_687458798759f_1752455289.jpg',NULL),(6,'PRT001','Printer Canon Pixma',5,1,800000.00,1200000.00,11,'produk_6874585ed9424_1752455262.jpg',NULL),(13,'BRG-0013','Printer Canon Pixma',10,1,1000000.00,1000000.00,9,'produk_6874c70c17c1c_1752483596.jpg',16),(14,'BRG-0014','Keyboard Gaming RGB',14,1,1000000.00,1000000.00,12,'produk_6874c72fb62f1_1752483631.jpg',16),(15,'BRG-0015','test3',11,2,1000000.00,1000000.00,1002,NULL,18),(16,'BRG-0016','test34',13,1,1000000.00,1000000.00,12,NULL,18),(20,'BRG-0020','test40',10,2,90000.00,90000.00,8,'produk_6874a6be8102a_1752475326.png',16),(21,'BRG-0021','test31',14,1,90000.00,90000.00,8,'produk_6874cb24ac9fb_1752484644.png',16);
/*!40000 ALTER TABLE `barang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kategori`
--

DROP TABLE IF EXISTS `kategori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kategori` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(50) NOT NULL,
  `deskripsi` text,
  `supplier_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_supplier` (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kategori`
--

LOCK TABLES `kategori` WRITE;
/*!40000 ALTER TABLE `kategori` DISABLE KEYS */;
INSERT INTO `kategori` VALUES (1,'Laptop','Kategori untuk laptop dan notebook',NULL),(2,'Komputer Desktop','Kategori untuk PC desktop',NULL),(3,'Aksesoris','Kategori untuk aksesoris komputer',NULL),(4,'Software','Kategori untuk software',NULL),(5,'Printer','Kategori untuk printer dan scanner',NULL),(9,'aksesoris gaming',NULL,15),(10,'Printer',NULL,16),(11,'kategori2',NULL,18),(13,'kategori9',NULL,18),(14,'Aksesoris',NULL,16);
/*!40000 ALTER TABLE `kategori` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pembelian`
--

DROP TABLE IF EXISTS `pembelian`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pembelian` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_pembelian` varchar(50) NOT NULL,
  `tanggal` date NOT NULL,
  `supplier_id` int NOT NULL,
  `user_id` int NOT NULL,
  `total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `status` enum('Belum Lunas','Proses','Lunas') NOT NULL DEFAULT 'Belum Lunas',
  `bukti_transfer` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `no_pembelian` (`no_pembelian`),
  KEY `fk_pembelian_supplier` (`supplier_id`),
  KEY `fk_pembelian_user` (`user_id`),
  CONSTRAINT `fk_pembelian_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`),
  CONSTRAINT `fk_pembelian_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pembelian`
--

LOCK TABLES `pembelian` WRITE;
/*!40000 ALTER TABLE `pembelian` DISABLE KEYS */;
INSERT INTO `pembelian` VALUES (6,'PBL202507100001','2025-07-10',16,1,0.00,'Lunas',NULL,'2025-07-10 02:03:57'),(7,'PBL202507100002','2025-07-10',16,1,100000000.00,'Lunas',NULL,'2025-07-10 02:52:13'),(8,'PBL202507100003','2025-07-10',16,1,100000000.00,'Lunas','bukti-8-686f33d4c19a6.png','2025-07-10 03:30:17'),(9,'PBL202507100004','2025-07-10',18,1,100000000.00,'Lunas',NULL,'2025-07-10 11:41:03'),(10,'PBL202507100005','2025-07-10',18,1,100000000.00,'Lunas','bukti-10-686fa6f99af52.png','2025-07-10 11:41:25'),(11,'PBL202507100006','2025-07-10',16,1,0.00,'Lunas',NULL,'2025-07-10 13:55:31'),(12,'PBL202507100007','2025-07-10',16,1,100000000.00,'Lunas',NULL,'2025-07-10 13:56:24'),(13,'PBL202507100008','2025-07-10',16,1,100000000.00,'Belum Lunas',NULL,'2025-07-10 13:57:18'),(23,'PBL202507110001','2025-07-11',16,1,1000000.00,'Proses','bukti-23-6870d3b717d2f.png','2025-07-11 07:40:17'),(24,'PBL202507110002','2025-07-11',16,1,1000000.00,'Lunas','bukti-24-6870d2646012d.png','2025-07-11 08:59:10'),(29,'PBL202507110003','2025-07-11',18,1,1000000.00,'Lunas','bukti-29-6870e7d2bfdc8.png','2025-07-11 10:29:54'),(30,'PBL202507110004','2025-07-11',18,1,1000000.00,'Lunas','bukti-30-6870e9114e2ea.png','2025-07-11 10:31:19'),(31,'PBL202507110005','2025-07-11',18,1,1000000.00,'Belum Lunas',NULL,'2025-07-11 10:33:40'),(32,'PBL202507110006','2025-07-11',18,1,1000000.00,'Belum Lunas',NULL,'2025-07-11 10:35:24'),(33,'PBL202507110007','2025-07-11',18,1,1000000.00,'Belum Lunas',NULL,'2025-07-11 10:35:46'),(34,'PBL202507140001','2025-07-14',16,1,1000000.00,'Lunas','bukti-34-6874ada5794e5.png','2025-07-14 07:11:22'),(35,'PBL202507140002','2025-07-14',16,1,90000.00,'Belum Lunas',NULL,'2025-07-14 07:39:44'),(36,'PBL202507140003','2025-07-14',16,1,90000.00,'Proses','bukti-36-6874b4e8aa982.png','2025-07-14 07:42:26');
/*!40000 ALTER TABLE `pembelian` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pembelian_detail`
--

DROP TABLE IF EXISTS `pembelian_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pembelian_detail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pembelian_id` int NOT NULL,
  `barang_id` int NOT NULL,
  `jumlah` int NOT NULL,
  `harga` decimal(12,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pembelian_detail_pembelian` (`pembelian_id`),
  KEY `fk_pembelian_detail_barang` (`barang_id`),
  CONSTRAINT `fk_pembelian_detail_barang` FOREIGN KEY (`barang_id`) REFERENCES `barang` (`id`),
  CONSTRAINT `fk_pembelian_detail_pembelian` FOREIGN KEY (`pembelian_id`) REFERENCES `pembelian` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pembelian_detail`
--

LOCK TABLES `pembelian_detail` WRITE;
/*!40000 ALTER TABLE `pembelian_detail` DISABLE KEYS */;
INSERT INTO `pembelian_detail` VALUES (7,7,13,1,100000000.00,100000000.00),(8,8,14,1,100000000.00,100000000.00),(9,9,15,1,100000000.00,100000000.00),(10,10,15,1,100000000.00,100000000.00),(12,12,13,1,100000000.00,100000000.00),(13,13,13,1,100000000.00,100000000.00),(14,23,14,1,1000000.00,1000000.00),(15,24,14,1,1000000.00,1000000.00),(16,29,16,1,1000000.00,1000000.00),(17,30,16,1,1000000.00,1000000.00),(18,31,16,1,1000000.00,1000000.00),(19,32,16,1,1000000.00,1000000.00),(20,33,16,1,1000000.00,1000000.00),(21,34,13,1,1000000.00,1000000.00),(22,35,20,1,90000.00,90000.00),(23,36,20,1,90000.00,90000.00);
/*!40000 ALTER TABLE `pembelian_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `satuan`
--

DROP TABLE IF EXISTS `satuan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `satuan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama_satuan` varchar(20) NOT NULL,
  `deskripsi` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `satuan`
--

LOCK TABLES `satuan` WRITE;
/*!40000 ALTER TABLE `satuan` DISABLE KEYS */;
INSERT INTO `satuan` VALUES (1,'Unit','Satuan unit/buah'),(2,'Set','Satuan set'),(3,'Paket','Satuan paket'),(4,'License','Satuan license software'),(5,'Meter','Satuan meter untuk kabel');
/*!40000 ALTER TABLE `satuan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama_supplier` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `telepon` varchar(20) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (1,'PT. Komputer Teknologi','Jl. Teknologi No. 123, Jakarta','021-1234567','info@komptek.com','komptek123'),(6,'CV. Jaya Abadi','Jl. Industri Raya No. 101, Bandung','022-555-1010','kontak@jayaabadi.com','jaya123'),(16,'CV Tri Muldianto Wijaya','banjarmasin','082339641431','tri@gmail.com','449060'),(18,'cv Hanifah Muslim','banjarmasin','082339641431','tet@gmail.com','323590');
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_barang`
--

DROP TABLE IF EXISTS `supplier_barang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier_barang` (
  `id` int NOT NULL AUTO_INCREMENT,
  `supplier_id` int NOT NULL,
  `barang_id` int NOT NULL,
  `harga_supplier` decimal(12,2) NOT NULL COMMENT 'Harga spesifik dari supplier ini',
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_barang_unik` (`supplier_id`,`barang_id`),
  KEY `fk_sb_supplier` (`supplier_id`),
  KEY `fk_sb_barang` (`barang_id`),
  CONSTRAINT `fk_sb_barang` FOREIGN KEY (`barang_id`) REFERENCES `barang` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sb_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_barang`
--

LOCK TABLES `supplier_barang` WRITE;
/*!40000 ALTER TABLE `supplier_barang` DISABLE KEYS */;
INSERT INTO `supplier_barang` VALUES (1,1,1,3450000.00),(2,1,3,4400000.00),(3,1,5,240000.00);
/*!40000 ALTER TABLE `supplier_barang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaksi`
--

DROP TABLE IF EXISTS `transaksi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaksi` (
  `id` int NOT NULL AUTO_INCREMENT,
  `no_transaksi` varchar(50) NOT NULL,
  `tanggal` date NOT NULL,
  `user_id` int NOT NULL,
  `total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `no_transaksi` (`no_transaksi`),
  KEY `fk_transaksi_user` (`user_id`),
  CONSTRAINT `fk_transaksi_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaksi`
--

LOCK TABLES `transaksi` WRITE;
/*!40000 ALTER TABLE `transaksi` DISABLE KEYS */;
INSERT INTO `transaksi` VALUES (1,'TRX20250709001','2025-07-09',2,4200000.00,'2025-07-09 08:59:46'),(2,'TRX202507100001','2025-07-10',1,4800000.00,'2025-07-09 22:13:45'),(3,'TRX202507100002','2025-07-10',1,1200000.00,'2025-07-10 00:17:32'),(4,'TRX202507100003','2025-07-10',1,4200000.00,'2025-07-10 13:49:40'),(5,'TRX202507110001','2025-07-11',1,120000.00,'2025-07-11 07:40:41'),(6,'TRX202507110002','2025-07-11',2,4200000.00,'2025-07-11 09:56:34'),(7,'TRX202507110003','2025-07-11',1,4800000.00,'2025-07-11 10:30:24');
/*!40000 ALTER TABLE `transaksi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaksi_detail`
--

DROP TABLE IF EXISTS `transaksi_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaksi_detail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transaksi_id` int NOT NULL,
  `barang_id` int NOT NULL,
  `jumlah` int NOT NULL,
  `harga` decimal(12,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_detail_transaksi` (`transaksi_id`),
  KEY `fk_detail_barang` (`barang_id`),
  CONSTRAINT `fk_detail_barang` FOREIGN KEY (`barang_id`) REFERENCES `barang` (`id`),
  CONSTRAINT `fk_detail_transaksi` FOREIGN KEY (`transaksi_id`) REFERENCES `transaksi` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaksi_detail`
--

LOCK TABLES `transaksi_detail` WRITE;
/*!40000 ALTER TABLE `transaksi_detail` DISABLE KEYS */;
INSERT INTO `transaksi_detail` VALUES (1,1,1,1,4200000.00,4200000.00),(2,2,2,1,4800000.00,4800000.00),(3,3,6,1,1200000.00,1200000.00),(4,4,1,1,4200000.00,4200000.00),(5,5,4,1,120000.00,120000.00),(6,6,1,1,4200000.00,4200000.00),(7,7,2,1,4800000.00,4800000.00);
/*!40000 ALTER TABLE `transaksi_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telepon` varchar(20) DEFAULT NULL,
  `alamat` text,
  `role` enum('admin','kasir') NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin123','Administrator',NULL,NULL,NULL,'admin'),(2,'kasir','kasir123','Kasir','','','','kasir');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-15 18:04:37
